﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//此代码由NFinalCompiler生成。
//http://bbs.nfinal.com
namespace $safeprojectname$.Controllers.IndexController_Model
{
	public class Index
	{
		[NFinal.ViewBagMember]
		public NFinal.Config.Plug.PlugConfig config;
	}
	public class Template
	{
		[NFinal.ViewBagMember]
		public NFinal.Config.Plug.PlugConfig config;
		public string Message;
	}
}

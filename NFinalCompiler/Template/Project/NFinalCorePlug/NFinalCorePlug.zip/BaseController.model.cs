﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using NFinal;
using NFinal.Http;
//此代码由NFinalCompiler生成。
//http://bbs.nfinal.com
namespace $safeprojectname$.BaseController_Model
{
}

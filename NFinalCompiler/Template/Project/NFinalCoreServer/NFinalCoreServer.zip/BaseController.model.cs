﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using NFinal;
//此代码由NFinalCompiler生成。
//http://bbs.nfinal.com
namespace $safeprojectname$.BaseController_Model
{
}

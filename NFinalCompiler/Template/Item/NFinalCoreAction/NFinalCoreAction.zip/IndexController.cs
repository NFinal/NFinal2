﻿using System;
using System.Collections.Generic;
using System.Text;
using NFinal;

namespace $rootnamespace$
{
    public class $safeitemname$:NFinal.CoreAction
    {
        public void Index()
        {
			
        }
    }
}
﻿/*
set @name=''
set @connectionString=''
set @providerName='MySql.Data.MySqlClient'
set @useStruct=1
*/
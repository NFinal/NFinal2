﻿using System;
using System.Collections.Generic;
using System.Text;
using NFinal;

namespace $rootnamespace$
{
    public class $safeitemname$ : BaseController
    {
        public void Index()
        {
			
        }
    }
}
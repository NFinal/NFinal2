﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $rootnamespace$
{
    public class $safeitemname$:NFinal.OwinAction
    {
        public void Index()
        {
			
        }
    }
}